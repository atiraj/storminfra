The PMML model file, as well as the sample raw input data file are from the `4.1	Regression	KNIME	KNIME 2.8`
[example] (http://dmg.org/pmml/pmml_examples/index.html)
 
 The PMML Model file matches the [example file] (http://dmg.org/pmml/pmml_examples/KNIME_PMML_4.1_Examples/single_audit_mlp.xml) 
 
 The file Audit.50.csv contains the first 50 lines of raw input data of the [Audit example] (http://dmg.org/pmml/pmml_examples/index.html#Audit). 